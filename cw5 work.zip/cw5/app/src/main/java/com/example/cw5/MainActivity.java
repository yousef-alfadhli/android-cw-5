package com.example.cw5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText x = findViewById(R.id.Y);
        final EditText y = findViewById(R.id.X);
        Button next = findViewById(R.id.nextPage);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nameInEditText = x.getText().toString();
                String ageInEditText = y.getText().toString();

                Intent intent = new Intent(MainActivity.this, MainActivity2.class );

                intent.putExtra("x" ,nameInEditText);
                intent.putExtra("y" ,ageInEditText);

                startActivity(intent);





            }
        });




    }
}