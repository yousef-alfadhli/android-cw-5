package com.example.cw5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
         final TextView H = findViewById(R.id.HP2);
         final TextView J = findViewById(R.id.PH2);
        Button F =findViewById(R.id.button);
        Bundle airport =getIntent().getExtras();

        String hh = airport.getString("x");
        String  jj = airport.getString("y");


        H.setText(hh);
        J.setText(jj);

        F.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent = new Intent(MainActivity2.this, MainActivity.class );

                startActivity(intent);

            }
        });


















    }
}